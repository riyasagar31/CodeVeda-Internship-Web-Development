// Toggle dropdown menu
function toggleMenu() {
  document.querySelector("#navbar ul").classList.toggle("show");
}

// Modal functions
function openModal() {
  document.getElementById("projectModal").style.display = "block";
}

function closeModal() {
  document.getElementById("projectModal").style.display = "none";
}

// Form validation
function validateForm() {
  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const message = document.getElementById("message").value.trim();
  const formMessage = document.getElementById("formMessage");

  if (name === "" || email === "" || message === "") {
    formMessage.textContent = "All fields are required.";
    formMessage.style.color = "red";
    return false;
  }

  if (!email.includes("@") || !email.includes(".")) {
    formMessage.textContent = "Please enter a valid email.";
    formMessage.style.color = "red";
    return false;
  }

  formMessage.textContent = "Message sent successfully!";
  formMessage.style.color = "green";
  return true;
}


// ========== Dropdown ==========
function toggleMenu() {
  document.querySelector("#navbar ul").classList.toggle("show");
}

// ========== Modal ==========
function openModal() {
  document.getElementById("projectModal").style.display = "block";
}

function closeModal() {
  document.getElementById("projectModal").style.display = "none";
}

// ========== Form Validation ==========
function validateForm() {
  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const message = document.getElementById("message").value.trim();
  const formMessage = document.getElementById("formMessage");

  if (!name || !email || !message) {
    formMessage.textContent = "All fields are required.";
    formMessage.style.color = "red";
    return false;
  }

  if (!email.includes("@") || !email.includes(".")) {
    formMessage.textContent = "Please enter a valid email.";
    formMessage.style.color = "red";
    return false;
  }

  formMessage.textContent = "Message sent successfully!";
  formMessage.style.color = "green";

  // Save to local storage
  localStorage.setItem("contactForm", JSON.stringify({ name, email, message }));

  return true;
}

// ========== Load Form Data ==========
window.onload = function () {
  const savedForm = JSON.parse(localStorage.getItem("contactForm"));
  if (savedForm) {
    document.getElementById("name").value = savedForm.name || "";
    document.getElementById("email").value = savedForm.email || "";
    document.getElementById("message").value = savedForm.message || "";
  }

  applyDarkMode(); // Apply dark mode preference
  animateSections(); // Add entrance animations
};

// ========== Dark Mode ==========
function toggleDarkMode() {
  const body = document.body;
  body.classList.toggle("dark");

  // Save preference
  const isDark = body.classList.contains("dark");
  localStorage.setItem("darkMode", isDark ? "enabled" : "disabled");
}

function applyDarkMode() {
  const mode = localStorage.getItem("darkMode");
  if (mode === "enabled") {
    document.body.classList.add("dark");
  }
}

// ========== Animations ==========
function animateSections() {
  const sections = document.querySelectorAll(".section");
  sections.forEach((section, index) => {
    section.style.opacity = 0;
    setTimeout(() => {
      section.style.opacity = 1;
      section.style.transform = "translateY(0)";
    }, index * 400);
  });
}


// Typing Text Animation
const words = ["Riya Sagar ", "a Front-End Web Developer "];
let wordIndex = 0;
let charIndex = 0;
let isDeleting = false;

function type() {
  const typedText = document.querySelector(".typed-text");
  const currentWord = words[wordIndex];
  if (isDeleting) {
    typedText.textContent = currentWord.substring(0, charIndex--);
  } else {
    typedText.textContent = currentWord.substring(0, charIndex++);
  }

  if (!isDeleting && charIndex === currentWord.length) {
    isDeleting = true;
    setTimeout(type, 1200); // Wait before deleting
  } else if (isDeleting && charIndex === 0) {
    isDeleting = false;
    wordIndex = (wordIndex + 1) % words.length;
    setTimeout(type, 300);
  } else {
    setTimeout(type, isDeleting ? 50 : 120);
  }
}

window.addEventListener("DOMContentLoaded", () => {
  type(); // start typing animation
});

// Scroll to top button
const topBtn = document.getElementById("topBtn");

window.onscroll = function () {
  if (document.body.scrollTop > 200 || document.documentElement.scrollTop > 200) {
    topBtn.style.display = "block";
  } else {
    topBtn.style.display = "none";
  }
};

function scrollToTop() {
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
